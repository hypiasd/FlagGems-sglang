"""Task 78 v24: flat (token*head) program mapping, one contiguous row per program."""
import torch
import triton
import triton.language as tl

@triton.jit
def _concat_flat_v24(
    out, nope, rope,
    H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BLOCK: tl.constexpr
):
    pid = tl.program_id(0)
    if WIDE:
        pid = pid.to(tl.int64)
    token = pid // H
    head = pid % H
    # Column tiles span the whole row; one iteration while BLOCK >= total_dim.
    for first_col in range(0, DN + DR, BLOCK):
        cols = first_col + tl.arange(0, BLOCK)
        in_row = cols < DN + DR
        # nope part: contiguous columns [0, DN)
        nc = cols
        nope_mask = cols < DN
        prefix = tl.load(
            nope + token * NS0 + head * NS1 + nc * NS2,
            mask=nope_mask, other=0
        ).to(COMMON)
        # rope part: broadcast rope[token, 0, cols-DN] to every head
        rc = tl.maximum(cols - DN, 0)
        rope_mask = (cols >= DN) & (cols < DN + DR)
        suffix = tl.load(
            rope + token * RS0 + rc * RS2,
            mask=rope_mask, other=0
        ).to(COMMON)
        value = tl.where(cols < DN, prefix, suffix)
        tl.store(
            out + pid * (DN + DR) + cols,
            value, mask=in_row
        )

def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    block = min(4096, triton.next_power_of_2(total_dim))
    _concat_flat_v24[(tokens * heads,)](
        out, k_nope, k_rope, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BLOCK=block,
        num_warps=4, num_stages=1
    )
    return out

__all__ = ["concat_and_cast_mha_k"]
