"""Task 78 v24: Ascend row blocks over a 32-program grid-stride loop."""
import torch
import triton
import triton.language as tl

@triton.jit
def _concat_row_blocks_v24(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BR: tl.constexpr, BN: tl.constexpr, BRC: tl.constexpr,
    ROW_BLOCKS: tl.constexpr
):
    D: tl.constexpr = DN + DR
    # Grid-stride over row blocks: the launch stays at the 32-program Ascend
    # cap and each program walks its blocks at runtime, so the body is not
    # unrolled once per block. Widen the block index before any multiply.
    for block in range(tl.program_id(0), ROW_BLOCKS, tl.num_programs(0)):
        if WIDE:
            block = block.to(tl.int64)
        rows = block * BR + tl.arange(0, BR)
        rmask = rows < T * H
        t = rows // H
        h = rows - t * H
        if DN > 0:
            for first_col in range(0, DN, BN):
                nc = first_col + tl.arange(0, BN)
                if WIDE:
                    nc = nc.to(tl.int64)
                nmask = rmask[:, None] & (nc[None, :] < DN)
                value = tl.load(
                    nope + t[:, None] * NS0 + h[:, None] * NS1
                    + nc[None, :] * NS2,
                    mask=nmask, other=0
                ).to(COMMON)
                tl.store(out + rows[:, None] * D + nc[None, :],
                         value, mask=nmask)
        if DR > 0:
            for first_rc in range(0, DR, BRC):
                rc = first_rc + tl.arange(0, BRC)
                if WIDE:
                    rc = rc.to(tl.int64)
                rmask2 = rmask[:, None] & (rc[None, :] < DR)
                rope_value = tl.load(
                    rope + t[:, None] * RS0 + rc[None, :] * RS2,
                    mask=rmask2, other=0
                ).to(COMMON)
                tl.store(out + rows[:, None] * D + DN + rc[None, :],
                         rope_value, mask=rmask2)

def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31

    # Capped power-of-two tiles (visible constants) to keep UB usage bounded.
    bn = max(1, min(512, triton.next_power_of_2(max(1, dn))))
    brc = max(1, min(4096, triton.next_power_of_2(max(1, dr))))
    br = max(1, min(128, triton.next_power_of_2(max(1, tokens * heads))))
    br = max(1, min(br, 8192 // max(bn, brc)))

    total_rows = tokens * heads
    row_blocks = triton.cdiv(total_rows, br)
    # Ascend caps the resident grid; the kernel grid-strides over every
    # remaining row block.
    grid = min(32, row_blocks)
    _concat_row_blocks_v24[(grid,)](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BR=br, BN=bn, BRC=brc,
        ROW_BLOCKS=row_blocks, num_warps=8, num_stages=1
    )
    return out

__all__ = ["concat_and_cast_mha_k"]
