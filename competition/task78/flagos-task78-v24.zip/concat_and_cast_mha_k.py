"""Task 78 v24: flat (token*head) row index, contiguous stores, capped power-of-two tiles."""
import torch
import triton
import triton.language as tl

@triton.jit
def _concat_flat_rows_v24(
    out, nope, rope,
    TH: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BR: tl.constexpr, BC: tl.constexpr
):
    pid = tl.program_id(0)
    if WIDE:
        pid = pid.to(tl.int64)
    rows = pid * BR + tl.arange(0, BR)
    if WIDE:
        rows = rows.to(tl.int64)
    rvalid = rows < TH
    token = rows // H
    head = rows % H
    # Column tiles span the whole row; one iteration while BC >= total_dim.
    for first_col in range(0, DN + DR, BC):
        cols = first_col + tl.arange(0, BC)
        valid = rvalid[:, None] & (cols[None, :] < DN + DR)
        nc = cols
        rc = tl.maximum(cols - DN, 0)
        prefix = tl.load(
            nope + token[:, None] * NS0 + head[:, None] * NS1 + nc[None, :] * NS2,
            mask=rvalid[:, None] & (cols[None, :] < DN), other=0
        ).to(COMMON)
        suffix = tl.load(
            rope + token[:, None] * RS0 + rc[None, :] * RS2,
            mask=rvalid[:, None] & (cols >= DN) & (cols < DN + DR), other=0
        ).to(COMMON)
        value = tl.where(cols[None, :] < DN, prefix, suffix)
        tl.store(out + rows[:, None] * (DN + DR) + cols[None, :],
                 value, mask=valid)

def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    th = tokens * heads
    bc = max(1, min(4096, triton.next_power_of_2(max(1, total_dim))))
    br = max(1, min(16, triton.next_power_of_2(max(1, th))))
    br = min(br, max(1, 4096 // bc))
    grid = (triton.cdiv(th, br))
    _concat_flat_rows_v24[(grid,)](
        out, k_nope, k_rope, th, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BR=br, BC=bc,
        num_warps=4, num_stages=2
    )
    return out

__all__ = ["concat_and_cast_mha_k"]
