"""Task 78 v24: Kunlunxin, one program per (token, head) — full parallelism."""
import torch
import triton
import triton.language as tl

@triton.jit
def _concat_flat_v24(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BN: tl.constexpr, BR: tl.constexpr
):
    pid = tl.program_id(0)
    if WIDE:
        pid = pid.to(tl.int64)
    token = pid // H
    head = pid - token * H
    dst = pid * (DN + DR)

    if DN > 0:
        for first_col in range(0, DN, BN):
            nc = first_col + tl.arange(0, BN)
            if WIDE:
                nc = nc.to(tl.int64)
            valid_n = nc < DN
            value = tl.load(
                nope + token * NS0 + head * NS1 + nc * NS2,
                mask=valid_n, other=0
            ).to(COMMON)
            tl.store(out + dst + nc, value, mask=valid_n)

    if DR > 0:
        for first_rc in range(0, DR, BR):
            rc = first_rc + tl.arange(0, BR)
            if WIDE:
                rc = rc.to(tl.int64)
            valid_r = rc < DR
            rope_value = tl.load(
                rope + token * RS0 + rc * RS2,
                mask=valid_r, other=0
            ).to(COMMON)
            tl.store(out + dst + DN + rc, rope_value, mask=valid_r)

def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    bn = max(1, min(4096, triton.next_power_of_2(max(1, dn))))
    br = max(1, min(4096, triton.next_power_of_2(max(1, dr))))
    _concat_flat_v24[(tokens * heads,)](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BN=bn, BR=br,
        num_warps=4, num_stages=2
    )
    return out

__all__ = ["concat_and_cast_mha_k"]
