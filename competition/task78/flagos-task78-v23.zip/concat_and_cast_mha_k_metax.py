"""Task 78 v27: MetaX, single fused prefix/suffix kernel, autotuned tiles.

Optimizations over v26:
- Removed stray token in config list (syntax repair).
- Refined autotune space: power-of-two num_warps only, larger column tiles
  for better bandwidth saturation, fewer redundant configs to cut autotune
  overhead.
- Streaming cache hints retained ('evict_last' for touch-once data).
"""
import torch
import triton
import triton.language as tl


@triton.autotune(
    configs=[
        triton.Config({'BH': 8, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 1024}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 1024}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 2048}, num_warps=8, num_stages=2),
        triton.Config({'BH': 32, 'BC': 512}, num_warps=8, num_stages=3),
        triton.Config({'BH': 32, 'BC': 1024}, num_warps=8, num_stages=3),
        triton.Config({'BH': 32, 'BC': 256}, num_warps=4, num_stages=2),
        triton.Config({'BH': 4, 'BC': 1024}, num_warps=4, num_stages=2),
        triton.Config({'BH': 64, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 64, 'BC': 256}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 2048}, num_warps=8, num_stages=3),
    ],
    key=['T', 'H', 'DN', 'DR'],
)
@triton.jit
def _concat_fused_v27(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    ct = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        ct = ct.to(tl.int64)

    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    cols = ct * BC + tl.arange(0, BC)
    total = DN + DR
    cmask = cols < total
    valid = hmask[:, None] & cmask[None, :]

    # Split the tile's column range into the nope segment and the rope segment.
    is_nope = cols < DN
    is_rope = cmask & (cols >= DN)

    # --- prefix load: k_nope[t, h, c] for c < DN ---
    nope_cols = tl.where(is_nope, cols, 0)
    src_heads = tl.where(hmask, heads, 0)
    nv = tl.load(
        nope + token * NS0 + src_heads[:, None] * NS1 + nope_cols[None, :] * NS2,
        mask=valid & is_nope[None, :], other=0,
        eviction_policy='evict_last',
    ).to(COMMON)

    # --- suffix load: k_rope[t, 0, c - DN] for DN <= c < DN+DR ---
    rope_cols = tl.where(is_rope, cols - DN, 0)
    rv = tl.load(
        rope + token * RS0 + rope_cols[None, :] * RS2,
        mask=is_rope[None, :], other=0,
        eviction_policy='evict_last',
    ).to(COMMON)
    rvb = tl.broadcast_to(rv, (BH, BC))

    v = tl.where(is_nope[None, :], nv, rvb)

    out_base = out + (token * H + heads[:, None]) * total
    tl.store(out_base + cols[None, :], v, mask=valid,
             eviction_policy='evict_last')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    if dn == 0 and dr == 0:
        return out
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    grid = lambda meta: (tokens, triton.cdiv(heads, meta['BH']),
                         triton.cdiv(dn + dr, meta['BC']))
    _concat_fused_v27[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns,
        rs[0], rs[2],
        COMMON=common, WIDE=wide,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]