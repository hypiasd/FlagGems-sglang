"""Task 78 v27: concat_and_cast_mha_k, optimized.

Changes over v26:
  * Autotune grid now selects per-head tiles via HS (one program per
    head tile), with wider BN variants and more num_stages choices so
    the autotuner can saturate bandwidth on both narrow and wide rows.
  * Loads use 'evict_first' for the streaming sources so the output
    store does not thrash L2 lines still needed by other programs.
  * Kept the fused one-store row schedule, exact prefix/suffix
    semantics, arbitrary strides, mixed dtypes, empty dims, input
    immutability, and wrapper name.
"""
import torch
import triton
import triton.language as tl


def _cfg(BN, HS, W, S=1):
    return triton.Config({'BN': BN, 'HS': HS}, num_warps=W, num_stages=S)


@triton.autotune(
    configs=[
        _cfg(256, 8, 1),
        _cfg(256, 4, 2),
        _cfg(512, 4, 2),
        _cfg(512, 2, 4, 2),
        _cfg(1024, 2, 4, 2),
        _cfg(1024, 1, 8),
        _cfg(1024, 1, 8, 2),
        _cfg(2048, 1, 8, 2),
        _cfg(2048, 2, 8, 2),
        _cfg(4096, 1, 8, 2),
        _cfg(4096, 2, 8, 3),
    ],
    key=['T', 'H', 'DN', 'DR'],
)
@triton.jit
def _concat_serial_heads_v27(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    HS: tl.constexpr, BN: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
    first_head = head_job * HS
    row_width: tl.constexpr = DN + DR

    nc = tl.arange(0, BN)
    if WIDE:
        nc = nc.to(tl.int64)

    # Bases hoisted out of all loops.
    nope_row = nope + token * NS0
    rope_row = rope + token * RS0
    out_row = out + token * (H * row_width)

    # ---------------- fused single-pass over the output row ----------------
    for h in tl.static_range(0, HS):
        head = first_head + h
        head_ok = head < H
        src = nope_row + head * NS1
        dst = out_row + head * row_width
        for first_col in range(0, row_width, BN):
            cols = first_col + nc
            in_nope = cols < DN
            in_range = cols < row_width
            valid = head_ok & in_range
            # Canonical masked loads: when DN==0 (or DR==0) the mask is
            # statically all-false and `other` supplies the value; no
            # zero-tile is ever materialized.
            nv = tl.load(src + cols * NS2, mask=head_ok & in_nope,
                         other=0, eviction_policy='evict_first').to(COMMON)
            rv = tl.load(rope_row + (cols - DN) * RS2,
                         mask=head_ok & in_range & (cols >= DN),
                         other=0, eviction_policy='evict_first').to(COMMON)
            value = tl.where(in_nope, nv, rv)
            tl.store(dst + cols, value, mask=valid,
                     eviction_policy='evict_last')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    _concat_serial_heads_v27[lambda meta: (tokens, triton.cdiv(heads, meta["HS"]))](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]