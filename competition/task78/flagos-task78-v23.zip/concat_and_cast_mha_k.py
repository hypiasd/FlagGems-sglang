"""Task 78 v24: single fused straight-line kernel for both segments.

Change from v23: the two separate prefix/suffix kernel launches are fused
into ONE kernel covering the full output column range [0, DN+DR). Each
column tile selects its source via complementary compile-time-independent
masks (no runtime program-id branch, straight-line code). This halves
kernel launch overhead and shares token/head index computation across
both segments. Rope values are loaded once per tile and broadcast across
heads. Promoted COMMON cast, streaming eviction hints, contiguous output
row stride DN+DR, and int64 WIDE indexing all preserved.
"""
import torch
import triton
import triton.language as tl


def _cfg(bh, bc, w, s):
    return triton.Config({"BH": bh, "BC": bc}, num_warps=w, num_stages=s)


@triton.autotune(
    configs=[
        _cfg(1, 1024, 4, 1),
        _cfg(2, 1024, 4, 1),
        _cfg(4, 1024, 4, 1),
        _cfg(4, 2048, 8, 1),
        _cfg(8, 1024, 4, 1),
        _cfg(8, 2048, 8, 1),
        _cfg(16, 512, 4, 1),
        _cfg(16, 1024, 8, 1),
        _cfg(4, 4096, 8, 1),
        _cfg(8, 4096, 8, 2),
    ],
    key=["T", "H", "DN", "DR"],
)
@triton.jit
def _concat_fused_v24(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)

    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H

    # Global output column index covering both segments.
    c = col_job * BC + tl.arange(0, BC)
    in_nope = c < DN
    in_range = c < DN + DR
    cmask = in_range

    # Nope segment: direct gather for columns < DN.
    v_nope = tl.load(
        nope + token * NS0 + heads[:, None] * NS1 + c[None, :] * NS2,
        mask=hmask[:, None] & in_nope[None, :], other=0,
        eviction_policy="evict_last",
    ).to(COMMON)

    # Rope segment: one row load per tile, broadcast across heads.
    rc = c - DN
    v_rope_row = tl.load(
        rope + token * RS0 + rc[None, :] * RS2,
        mask=(~in_nope & cmask)[None, :], other=0,
        eviction_policy="evict_last",
    ).to(COMMON)
    v_rope = tl.broadcast_to(v_rope_row, (BH, BC))

    val = tl.where(in_nope[None, :], v_nope, v_rope)

    mask = hmask[:, None] & cmask[None, :]
    tl.store(
        out + (token * H + heads[:, None]) * (DN + DR) + c[None, :],
        val, mask=mask, eviction_policy="evict_first",
    )


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31

    grid = lambda meta: (
        tokens,
        triton.cdiv(heads, meta["BH"]),
        triton.cdiv(dn + dr, meta["BC"]),
    )
    _concat_fused_v24[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns,
        rs[0], rs[2],
        COMMON=common, WIDE=wide,
    )

    return out


__all__ = ["concat_and_cast_mha_k"]