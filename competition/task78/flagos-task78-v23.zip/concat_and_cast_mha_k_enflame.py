"""Task 78 v25: single-pass fused column schedule — nope and rope tiles combined
into one output tile per chunk, rope loaded once per chunk and reused across
heads. v25 removes the tl.zeros fallback (compile-time-safe masked load with
explicit `other` instead) and tunes num_stages for the memory-bound schedule."""
import torch
import triton
import triton.language as tl


def _cfg(hs, nw, ns):
    return triton.Config({'HS': hs}, num_warps=nw, num_stages=ns)


# All num_warps must be positive powers of two (compiler-risk gate).
_ALL_CONFIGS = [
    _cfg(1, 4, 2), _cfg(1, 8, 2), _cfg(1, 16, 2),
    _cfg(2, 4, 2), _cfg(2, 8, 2), _cfg(2, 16, 2),
    _cfg(4, 4, 2), _cfg(4, 8, 2), _cfg(4, 16, 2),
    _cfg(8, 8, 2), _cfg(8, 16, 2),
    _cfg(16, 8, 2), _cfg(16, 16, 2),
    _cfg(32, 8, 2), _cfg(32, 16, 2),
]


@triton.autotune(configs=_ALL_CONFIGS, key=['T', 'H', 'DN', 'DR'])
@triton.jit
def _concat_fused_cols_v25(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    HS: tl.constexpr, BR: tl.constexpr, NRC: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
    first_head = head_job * HS

    # Single pass over the fused output row [0, DN+DR): each BR-wide chunk
    # loads the rope slice once (shared across heads) and the per-head nope
    # slice, merges them with tl.where, and stores once per head.
    for rblk in tl.static_range(0, NRC):
        col = tl.arange(0, BR)
        if WIDE:
            col = col.to(tl.int64)
        col = rblk * BR + col
        in_nope = col < DN
        in_range = col < DN + DR
        rope_mask = (~in_nope) & in_range

        # Shared rope slice: loaded once per chunk, broadcast to all heads.
        # Masked load with explicit `other` keeps zero-DR/zero-DN cases
        # compile-time safe without tl.zeros.
        rope_value = tl.load(
            rope + token * RS0 + (col - DN) * RS2,
            mask=rope_mask, other=0,
            eviction_policy='evict_first',
        ).to(COMMON)

        for h in tl.static_range(0, HS):
            head = first_head + h
            head_ok = head < H
            dst = (token * H + head) * (DN + DR)
            nope_value = tl.load(
                nope + token * NS0 + head * NS1 + col * NS2,
                mask=head_ok & in_nope, other=0,
                eviction_policy='evict_last',
            ).to(COMMON)
            if DR > 0:
                value = tl.where(in_nope, nope_value, rope_value)
            else:
                value = nope_value
            tl.store(out + dst + col, value,
                     mask=head_ok & in_range,
                     eviction_policy='evict_last')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    # One block size covers the fused row DN+DR; bounded cap avoids unbounded
    # next_power_of_2 blowups while NRC chunks cover the remainder.
    BR_CAP = 1024
    br = min(BR_CAP, triton.next_power_of_2(max(1, dn + dr)))
    nrc = triton.cdiv(max(1, dn + dr), br)
    # Grid safety: grid.y must stay <= 255. The kernel masks out-of-range heads
    # (head_ok), so larger HS configs are safe; autotune picks the best one.
    grid = lambda meta: (tokens, triton.cdiv(heads, meta['HS']))
    _concat_fused_cols_v25[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BR=br, NRC=nrc,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]