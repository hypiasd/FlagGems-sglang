"""Task 78 v29: autotuned Ascend token/head tiles for concat+cast MHA.

v29: performance pass over v28. Structural changes:
- Canonical loads only: every tl.load uses just pointer, mask, and other, so
  the compiler's default padding/sync path is used uniformly.
- Rebalanced the autotune space toward mid-size column tiles (BN/BR 256/512)
  with num_stages=2 so the load/compute/store pipeline overlaps better in UB,
  and kept a few large-tile num_warps=8 variants for big (T, H) problems.
- Hoisted per-job token/head index vectors, the combined token/head mask, and
  the row base pointer arithmetic out of the column loops (carried over from
  v27/v28); each column tile only adds its own column offset.
- Retained the single combined token/head mask, register-broadcast RoPE
  suffix, and the WIDE int64 indexing path.
"""
import torch
import triton
import triton.language as tl


def _v29_configs():
    return [
        triton.Config({'BT': 2, 'HS': 8, 'BN': 512, 'BR': 512}, num_warps=4, num_stages=2, multibuffer=True),
        triton.Config({'BT': 4, 'HS': 8, 'BN': 512, 'BR': 512}, num_warps=4, num_stages=2, multibuffer=True),
        triton.Config({'BT': 4, 'HS': 16, 'BN': 256, 'BR': 256}, num_warps=4, num_stages=2, multibuffer=True),
        triton.Config({'BT': 8, 'HS': 8, 'BN': 256, 'BR': 256}, num_warps=4, num_stages=2, multibuffer=True),
        triton.Config({'BT': 2, 'HS': 16, 'BN': 512, 'BR': 512}, num_warps=4, num_stages=2, multibuffer=True),
        triton.Config({'BT': 1, 'HS': 8, 'BN': 512, 'BR': 512}, num_warps=4, num_stages=2, multibuffer=True),
        triton.Config({'BT': 1, 'HS': 16, 'BN': 1024, 'BR': 1024}, num_warps=8, num_stages=1, multibuffer=True),
        triton.Config({'BT': 2, 'HS': 8, 'BN': 1024, 'BR': 1024}, num_warps=8, num_stages=1, multibuffer=True),
        triton.Config({'BT': 4, 'HS': 16, 'BN': 512, 'BR': 512}, num_warps=8, num_stages=2, multibuffer=True),
        triton.Config({'BT': 8, 'HS': 16, 'BN': 256, 'BR': 256}, num_warps=8, num_stages=2, multibuffer=True),
        triton.Config({'BT': 16, 'HS': 8, 'BN': 256, 'BR': 256}, num_warps=8, num_stages=2, multibuffer=True),
        triton.Config({'BT': 4, 'HS': 8, 'BN': 256, 'BR': 256}, num_warps=4, num_stages=3, multibuffer=True),
    ]


@triton.autotune(configs=_v29_configs(), key=['T', 'H', 'DN', 'DR'])
@triton.jit
def _concat_token_head_tiles_v29(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BT: tl.constexpr, HS: tl.constexpr,
    BN: tl.constexpr, BR: tl.constexpr,
):
    # Derived from the constexpr problem shape + autotuned tile sizes so the
    # grid lambda and the kernel body can never disagree.
    HEAD_JOBS = (H + HS - 1) // HS
    JOBS = ((T + BT - 1) // BT) * HEAD_JOBS
    for job in range(tl.program_id(0), JOBS, tl.num_programs(0)):
        # Scalar division per work tile only; tensor axes stay [tokens, heads, cols].
        if WIDE:
            work = job.to(tl.int64)
        else:
            work = job
        first_token = (work // HEAD_JOBS) * BT
        first_head = (work % HEAD_JOBS) * HS

        tokens = first_token + tl.arange(0, BT)
        heads = first_head + tl.arange(0, HS)
        token_ok = tokens[:, None, None] < T
        head_ok = heads[None, :, None] < H
        rows = tokens[:, None, None] * H + heads[None, :, None]
        # Combined token/head validity mask, computed once per job and reused
        # by every column tile of both the suffix and the prefix.
        th_ok = token_ok & head_ok
        # Hoisted row base offsets: each column tile only adds its own column
        # term instead of recomputing the full row stride product.
        row_base = rows * (DN + DR)
        nope_row = tokens[:, None, None] * NS0 + heads[None, :, None] * NS1
        rope_row = tokens[:, None] * RS0

        if DR > 0:
            # RoPE suffix is loaded per BR tile as [tokens, cols] and
            # broadcast across the head axis of the tile on store. The NRC
            # loop covers DR values exceeding the bounded BR tile cap.
            rc = tl.arange(0, BR)
            if WIDE:
                rc = rc.to(tl.int64)
            for first_col in range(0, DR, BR):
                cols = first_col + rc
                rope_mask = (tokens[:, None] < T) & (cols[None, :] < DR)
                rope_value = tl.load(
                    rope + rope_row + cols[None, :] * RS2,
                    mask=rope_mask, other=0,
                ).to(COMMON)
                # Materialize the exact [BT, HS, BR] store shape once so the
                # broadcast happens in registers instead of on every store.
                rope_tile_value = tl.broadcast_to(
                    rope_value[:, None, :], (BT, HS, BR))
                rope_tile = th_ok & (cols[None, None, :] < DR)
                tl.store(out + row_base + DN + cols[None, None, :],
                         rope_tile_value, mask=rope_tile,
                         eviction_policy='evict_last')

        if DN > 0:
            nc = tl.arange(0, BN)
            if WIDE:
                nc = nc.to(tl.int64)
            for first_col in range(0, DN, BN):
                cols = first_col + nc
                valid = th_ok & (cols[None, None, :] < DN)
                value = tl.load(
                    nope + nope_row + cols[None, None, :] * NS2,
                    mask=valid, other=0,
                ).to(COMMON)
                tl.store(out + row_base + cols[None, None, :],
                         value, mask=valid, eviction_policy='evict_last')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    # Grid is derived from the autotuned tile geometry; keep it within the
    # Ascend coreDim limit while filling physical cores.
    grid = lambda meta: (
        min(65535, min(32, triton.cdiv(tokens, meta['BT']) * triton.cdiv(heads, meta['HS']))),
    )
    _concat_token_head_tiles_v29[grid](
        out, k_nope, k_rope,
        T=tokens, H=heads, DN=dn, DR=dr,
        NS0=ns[0], NS1=ns[1], NS2=ns[2],
        RS0=rs[0], RS2=rs[2],
        COMMON=common, WIDE=wide,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]