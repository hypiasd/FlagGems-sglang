"""Task 78 v23: Iluvitar, single fused kernel (nope prefix + rope suffix in one pass).

One program per (token, head-block) writes the full DN+DR row span in a single
pass. Column loop trip counts are passed as constexpr (NC/RC, computed on the
host with canonical triton.cdiv), so there are no runtime program-id branches,
no tl.cdiv in device code, and no unbounded tiles.
"""
import torch
import triton
import triton.language as tl


@triton.autotune(
    configs=[
        triton.Config({'BH': 4, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 4, 'BC': 1024}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 1024}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 256}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 256}, num_warps=4, num_stages=3),
        triton.Config({'BH': 2, 'BC': 2048}, num_warps=8, num_stages=2),
        triton.Config({'BH': 1, 'BC': 4096}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 8, 'BC': 2048}, num_warps=8, num_stages=3),
        triton.Config({'BH': 16, 'BC': 1024}, num_warps=8, num_stages=2),
    ],
    key=['T', 'H', 'DN', 'DR'],
)
@triton.jit
def _concat_kernel(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    HAVE_N: tl.constexpr, HAVE_R: tl.constexpr,
    NC: tl.constexpr, RC: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    # One row-base computation shared by both the prefix and suffix stores.
    out_row = (token * H + heads[:, None]) * (DN + DR)

    if HAVE_N:
        # Dense nope stream: streaming, use once (evict_last).
        for col_job in tl.static_range(0, NC):
            cols = col_job * BC + tl.arange(0, BC)
            cmask = cols < DN
            m = hmask[:, None] & cmask[None, :]
            v = tl.load(
                nope + token * NS0 + heads[:, None] * NS1 + cols[None, :] * NS2,
                mask=m, other=0, eviction_policy='evict_last',
            )
            tl.store(out + out_row + cols[None, :], v.to(COMMON), mask=m)

    if HAVE_R:
        # Rope row is broadcast across BH heads: keep it hot (evict_first).
        for col_job in tl.static_range(0, RC):
            cols = col_job * BC + tl.arange(0, BC)
            cmask = cols < DR
            v = tl.load(
                rope + token * RS0 + cols * RS2,
                mask=cmask, other=0, eviction_policy='evict_first',
            )
            m = hmask[:, None] & cmask[None, :]
            tl.store(out + out_row + (DN + cols)[None, :],
                     tl.broadcast_to(v.to(COMMON)[None, :], (BH, BC)), mask=m)


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Native-width indices on ordinary tensors; widen before multiplication when
    # any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31

    if dn > 0 or dr > 0:
        # Canonical host-side grid arithmetic only; trip counts passed as constexpr.
        nc = triton.cdiv(dn, 512) if dn > 0 else 1
        rc = triton.cdiv(dr, 512) if dr > 0 else 1
        grid = lambda meta: (tokens, triton.cdiv(heads, meta['BH']))
        _concat_kernel[grid](
            out, k_nope, k_rope, tokens, heads, dn, dr,
            ns[0], ns[1], ns[2], rs[0], rs[2],
            COMMON=common, WIDE=wide,
            HAVE_N=(dn > 0), HAVE_R=(dr > 0),
            NC=nc, RC=rc,
        )
    return out


__all__ = ["concat_and_cast_mha_k"]