"""Task 78 v28: Hygon, fused single-store tile with shape-aware specialization.
NO_SPLIT fast path retained; rope suffix path now broadcasts the 1-D rope
vector to the [BH, BC] head matrix BEFORE the .to(COMMON) cast, so only one
cast is issued per element and no cast-before-broadcast expression remains."""
import torch
import triton
import triton.language as tl


def _cfgs():
    cfgs = []
    for bc in (128, 256, 512, 1024, 2048):
        for bh in (1, 2, 4, 8):
            if bh * bc > 8192:
                continue
            for nw in (2, 4, 8):
                for nst in (1, 2):
                    cfgs.append(triton.Config(
                        {'BH': bh, 'BC': bc}, num_warps=nw, num_stages=nst))
    return cfgs


@triton.autotune(
    configs=_cfgs(),
    key=['T', 'H', 'DN', 'DR', 'NS0', 'NS1', 'NS2', 'RS0', 'RS2',
         'COMMON', 'WIDE', 'NO_SPLIT'],
)
@triton.jit
def _concat_output_tile_v28(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr, NO_SPLIT: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    cols = col_job * BC + tl.arange(0, BC)
    hmask = heads[:, None] < H
    inrange = cols < DN + DR
    if NO_SPLIT:
        # Entire grid maps cols directly onto nope storage; rope is empty or
        # unreachable, so a single load + store with no merge logic.
        nc = tl.where(inrange, cols, 0)
        val = tl.load(
            nope + token * NS0 + heads[:, None] * NS1 + nc[None, :] * NS2,
            mask=hmask & inrange[None, :], other=0,
            eviction_policy='evict_last',
        ).to(COMMON)
    else:
        is_pre = cols < DN
        nc = tl.where(is_pre, cols, 0)
        prefix = tl.load(
            nope + token * NS0 + heads[:, None] * NS1 + nc[None, :] * NS2,
            mask=hmask & is_pre[None, :], other=0,
            eviction_policy='evict_last',
        ).to(COMMON)
        val = prefix
        if DR > 0:
            is_suf = (cols >= DN) & inrange
            rc = tl.where(is_suf, cols - DN, 0)
            suffix_row = tl.load(
                rope + token * RS0 + rc * RS2,
                mask=is_suf, other=0,
                eviction_policy='evict_last',
            )
            # Broadcast the raw 1-D rope vector to the [BH, BC] head matrix
            # first, then cast once — no cast-before-broadcast expression.
            suffix = tl.broadcast_to(suffix_row[None, :], (BH, BC)).to(COMMON)
            val = tl.where(is_pre[None, :], prefix, suffix)
    base = out + (token * H + heads[:, None]) * (DN + DR) + cols[None, :]
    tl.store(base, val, mask=hmask & inrange[None, :],
             eviction_policy='evict_first')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    # Shape-aware specialization: when the rope part is empty, every column
    # comes from nope storage and the merge path can be compiled out entirely.
    no_split = (dr == 0)
    grid = lambda META: (
        tokens,
        triton.cdiv(heads, META['BH']),
        triton.cdiv(total_dim, META['BC']),
    )
    _concat_output_tile_v28[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, NO_SPLIT=no_split,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]