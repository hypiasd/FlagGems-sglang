"""Task 78 v22: Iluvitar, two straight-line kernels (nope prefix + rope suffix).

Optimized: single promoted cast per element (load -> COMMON -> store), streaming
eviction hints tuned per access pattern (evict_first for the broadcast rope row
which is reused across heads, evict_last for the dense nope stream), and wider
autotune configs with more stages for better memory-level parallelism.
"""
import torch
import triton
import triton.language as tl


@triton.autotune(
    configs=[
        triton.Config({'BH': 4, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 4, 'BC': 1024}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 1024}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 256}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 256}, num_warps=4, num_stages=3),
        triton.Config({'BH': 2, 'BC': 2048}, num_warps=8, num_stages=2),
        triton.Config({'BH': 1, 'BC': 4096}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 8, 'BC': 2048}, num_warps=8, num_stages=3),
    ],
    key=['T', 'H', 'DN', 'DR'],
)
@triton.jit
def _concat_nope_kernel(
    out, nope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    out_row = (token * H + heads[:, None]) * (DN + DR)
    cols = col_job * BC + tl.arange(0, BC)
    cmask = cols < DN
    m = hmask[:, None] & cmask[None, :]
    # Single cast: load raw, promote once to COMMON, store (out dtype == k dtype).
    v = tl.load(
        nope + token * NS0 + heads[:, None] * NS1 + cols[None, :] * NS2,
        mask=m, other=0, eviction_policy='evict_last',
    )
    tl.store(out + out_row + cols[None, :], v.to(COMMON), mask=m)


@triton.autotune(
    configs=[
        triton.Config({'BH': 4, 'BC': 64}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 64}, num_warps=4, num_stages=2),
        triton.Config({'BH': 16, 'BC': 64}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 128}, num_warps=4, num_stages=2),
        triton.Config({'BH': 16, 'BC': 128}, num_warps=8, num_stages=2),
        triton.Config({'BH': 8, 'BC': 256}, num_warps=4, num_stages=2),
        triton.Config({'BH': 4, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 32, 'BC': 64}, num_warps=4, num_stages=2),
        triton.Config({'BH': 32, 'BC': 128}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 256}, num_warps=8, num_stages=2),
    ],
    key=['T', 'H', 'DN', 'DR'],
)
@triton.jit
def _concat_rope_kernel(
    out, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    out_row = (token * H + heads[:, None]) * (DN + DR)
    cols = col_job * BC + tl.arange(0, BC)
    cmask = cols < DR
    # Rope row is broadcast across BH heads: keep it hot in cache (evict_first).
    v = tl.load(
        rope + token * RS0 + cols * RS2,
        mask=cmask, other=0, eviction_policy='evict_first',
    )
    m = hmask[:, None] & cmask[None, :]
    tl.store(out + out_row + (DN + cols)[None, :],
             tl.broadcast_to(v.to(COMMON)[None, :], (BH, BC)), mask=m)


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Native-width indices on ordinary tensors; widen before multiplication when
    # any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31

    if dn > 0:
        grid_nope = lambda meta: (
            tokens, triton.cdiv(heads, meta['BH']), triton.cdiv(dn, meta['BC']),
        )
        _concat_nope_kernel[grid_nope](
            out, k_nope, tokens, heads, dn, dr,
            ns[0], ns[1], ns[2],
            COMMON=common, WIDE=wide,
        )
    if dr > 0:
        grid_rope = lambda meta: (
            tokens, triton.cdiv(heads, meta['BH']), triton.cdiv(dr, meta['BC']),
        )
        _concat_rope_kernel[grid_rope](
            out, k_rope, tokens, heads, dn, dr,
            rs[0], rs[2],
            COMMON=common, WIDE=wide,
        )
    return out


__all__ = ["concat_and_cast_mha_k"]
