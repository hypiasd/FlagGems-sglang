"""Task 78 v23: two-phase prefix/suffix schedule, rope loaded once per chunk, autotuned."""
import torch
import triton
import triton.language as tl


def _cfg(hs, nw):
    return triton.Config({'HS': hs}, num_warps=nw, num_stages=1)


_ALL_CONFIGS = [
    _cfg(1, 8), _cfg(1, 12), _cfg(1, 16),
    _cfg(2, 8), _cfg(2, 12), _cfg(2, 16),
    _cfg(4, 8), _cfg(4, 12), _cfg(4, 16),
    _cfg(8, 12), _cfg(8, 16),
    _cfg(16, 12), _cfg(16, 16),
    _cfg(32, 12), _cfg(32, 16),
]


@triton.autotune(configs=_ALL_CONFIGS, key=['T', 'H', 'DN', 'DR'])
@triton.jit
def _concat_serial_heads_v23(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    HS: tl.constexpr, BN: tl.constexpr, BR: tl.constexpr, NRC: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
    first_head = head_job * HS

    # Phase 1: prefix (nope) columns — independent of DR, runs exactly once
    # per (token, head), never duplicated by the rope chunk loop.
    if DN > 0:
        full = DN // BN
        for h in tl.static_range(0, HS):
            head = first_head + h
            head_ok = head < H
            dst = (token * H + head) * (DN + DR)
            for blk in range(0, full):
                nc = tl.arange(0, BN)
                if WIDE:
                    nc = nc.to(tl.int64)
                nc = blk * BN + nc
                value = tl.load(nope + token * NS0 + head * NS1 + nc * NS2,
                                mask=head_ok, other=0,
                                eviction_policy='evict_last').to(COMMON)
                tl.store(out + dst + nc, value, mask=head_ok,
                         eviction_policy='evict_last')
            tail = DN - full * BN
            if tail > 0:
                tc = tl.arange(0, BN)
                if WIDE:
                    tc = tc.to(tl.int64)
                tc = full * BN + tc
                valid = head_ok & (tc < DN)
                value = tl.load(nope + token * NS0 + head * NS1 + tc * NS2,
                                mask=valid, other=0,
                                eviction_policy='evict_last').to(COMMON)
                tl.store(out + dst + tc, value, mask=valid,
                         eviction_policy='evict_last')

    # Phase 2: rope suffix — each BR-chunk of the shared rope row is loaded
    # once per program and broadcast-stored across all heads in this program.
    if DR > 0:
        for rblk in tl.static_range(0, NRC):
            rc = tl.arange(0, BR)
            if WIDE:
                rc = rc.to(tl.int64)
            rc = rblk * BR + rc
            rope_value = tl.load(rope + token * RS0 + rc * RS2,
                                 mask=rc < DR, other=0,
                                 eviction_policy='evict_first').to(COMMON)
            for h in tl.static_range(0, HS):
                head = first_head + h
                head_ok = head < H
                dst = (token * H + head) * (DN + DR)
                tl.store(out + dst + DN + rc, rope_value,
                         mask=head_ok & (rc < DR),
                         eviction_policy='evict_last')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    bn = min(512, triton.next_power_of_2(max(1, dn)))
    # Bounded cap on the rope block: avoids unbounded next_power_of_2 blowups
    # while BR still covers DR via the NRC chunk loop inside the kernel.
    BR_CAP = 1024
    br = min(BR_CAP, triton.next_power_of_2(max(1, dr)))
    nrc = triton.cdiv(max(1, dr), br)
    # Grid safety: grid.y must stay <= 255. The kernel masks out-of-range heads
    # (head_ok), so larger HS configs are safe; autotune picks the best one.
    # The autotune-selected HS is part of the grid mapping; using a fixed
    # 32 here under-covers heads when the first/selected config uses HS < 32.
    grid = lambda meta: (tokens, triton.cdiv(heads, meta['HS']))
    _concat_serial_heads_v23[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BN=bn, BR=br, NRC=nrc,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
