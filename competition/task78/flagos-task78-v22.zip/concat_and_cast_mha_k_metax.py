"""Task 78 v24: MetaX, separate straight-line prefix/suffix kernels, autotuned tiles.

Fix: grid must be derived from the *selected* autotune meta (BH/BC), not a
hard-coded 1024. Zero-length segments are skipped so no invalid loads launch.
"""
import torch
import triton
import triton.language as tl


@triton.autotune(
    configs=[
        triton.Config({'BH': 8, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 1024}, num_warps=8, num_stages=2),
        triton.Config({'BH': 32, 'BC': 512}, num_warps=8, num_stages=3),
        triton.Config({'BH': 16, 'BC': 256}, num_warps=4, num_stages=2),
    ],
    key=['T', 'H', 'DN'],
)
@triton.jit
def _concat_prefix_v24(
    out, nope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    ct = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        ct = ct.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    cols = ct * BC + tl.arange(0, BC)
    cmask = cols < DN
    valid = hmask[:, None] & cmask[None, :]
    # Clamp masked source offsets into range to keep addresses safe.
    src_cols = tl.where(cmask, cols, 0)
    src_heads = tl.where(hmask, heads, 0)
    v = tl.load(
        nope + token * NS0 + src_heads[:, None] * NS1 + src_cols[None, :] * NS2,
        mask=valid, other=0, eviction_policy='evict_first',
    ).to(COMMON)
    out_base = out + (token * H + heads[:, None]) * (DN + DR)
    tl.store(out_base + cols[None, :], v, mask=valid)


@triton.autotune(
    configs=[
        triton.Config({'BH': 8, 'BC': 512}, num_warps=4, num_stages=2),
        triton.Config({'BH': 8, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 512}, num_warps=8, num_stages=2),
        triton.Config({'BH': 16, 'BC': 1024}, num_warps=8, num_stages=2),
        triton.Config({'BH': 32, 'BC': 512}, num_warps=8, num_stages=3),
        triton.Config({'BH': 16, 'BC': 256}, num_warps=4, num_stages=2),
    ],
    key=['T', 'H', 'DR'],
)
@triton.jit
def _concat_suffix_v24(
    out, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    ct = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        ct = ct.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    cols = ct * BC + tl.arange(0, BC)
    cmask = cols < DR
    # Source mask shaped [1, BC]: rope has a single head, so the load operates
    # on one row; the loaded value is then explicitly broadcast to [BH, BC]
    # for the store (no implicit broadcasting).
    src_valid = cmask[None, :]
    src_cols = tl.where(cmask, cols, 0)
    v = tl.load(
        rope + token * RS0 + src_cols[None, :] * RS2,
        mask=src_valid, other=0, eviction_policy='evict_first',
    ).to(COMMON)
    vb = tl.broadcast_to(v, (BH, BC))
    valid = hmask[:, None] & cmask[None, :]
    out_base = out + (token * H + heads[:, None]) * (DN + DR)
    tl.store(out_base + (DN + cols)[None, :], vb, mask=valid)


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    if dn == 0 and dr == 0:
        return out
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    if dn > 0:
        # Grid derived from the *selected* autotune meta so BC/BH always cover
        # the full DN/H extents (no hard-coded 1024 tile assumption).
        grid_p = lambda meta: (tokens, triton.cdiv(heads, meta['BH']),
                               triton.cdiv(dn, meta['BC']))
        _concat_prefix_v24[grid_p](
            out, k_nope, tokens, heads, dn, dr,
            *ns,
            COMMON=common, WIDE=wide,
        )
    if dr > 0:
        grid_s = lambda meta: (tokens, triton.cdiv(heads, meta['BH']),
                               triton.cdiv(dr, meta['BC']))
        _concat_suffix_v24[grid_s](
            out, k_rope, tokens, heads, dn, dr,
            rs[0], rs[2],
            COMMON=common, WIDE=wide,
        )
    return out


__all__ = ["concat_and_cast_mha_k"]
