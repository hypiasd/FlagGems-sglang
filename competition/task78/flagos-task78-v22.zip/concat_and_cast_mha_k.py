"""Task 78 v23: two separate straight-line prefix/suffix JIT kernels.

Change from v22: the single branched kernel (runtime `if col_job >= NP`)
is split into two dedicated JIT kernels — one for the nope prefix segment
and one for the rope suffix segment. Each kernel is straight-line (no
data-dependent branch on program_id), which removes the divergent branch
and lets the compiler specialize each path fully. Autotune retained over
(BH, BC, num_warps, num_stages) with per-kernel grids. Promoted COMMON
cast before stores, streaming eviction hints, output row stride DN+DR,
and int64 WIDE indexing all preserved.
"""
import torch
import triton
import triton.language as tl


def _cfg(bh, bc, w, s):
    return triton.Config({"BH": bh, "BC": bc}, num_warps=w, num_stages=s)


@triton.autotune(
    configs=[
        _cfg(1, 1024, 4, 1),
        _cfg(2, 1024, 4, 1),
        _cfg(4, 1024, 4, 1),
        _cfg(4, 2048, 8, 1),
        _cfg(8, 1024, 4, 1),
        _cfg(8, 2048, 8, 1),
        _cfg(16, 512, 4, 1),
        _cfg(16, 1024, 8, 1),
        _cfg(4, 4096, 8, 1),
        _cfg(8, 4096, 8, 2),
    ],
    key=["T", "H", "DN", "DR"],
)
@triton.jit
def _concat_prefix_v23(
    out, nope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)

    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H

    # Prefix segment: nope columns, direct 2-D tile load.
    c = col_job * BC + tl.arange(0, BC)
    cmask = c < DN
    mask = hmask[:, None] & cmask[None, :]
    val = tl.load(
        nope + token * NS0 + heads[:, None] * NS1 + c[None, :] * NS2,
        mask=mask, other=0,
        eviction_policy="evict_last",
    ).to(COMMON)

    tl.store(
        out + (token * H + heads[:, None]) * (DN + DR) + c[None, :],
        val, mask=mask, eviction_policy="evict_first",
    )


@triton.autotune(
    configs=[
        _cfg(1, 1024, 4, 1),
        _cfg(2, 1024, 4, 1),
        _cfg(4, 1024, 4, 1),
        _cfg(4, 2048, 8, 1),
        _cfg(8, 1024, 4, 1),
        _cfg(8, 2048, 8, 1),
        _cfg(16, 512, 4, 1),
        _cfg(16, 1024, 8, 1),
        _cfg(4, 4096, 8, 1),
        _cfg(8, 4096, 8, 2),
    ],
    key=["T", "H", "DN", "DR"],
)
@triton.jit
def _concat_suffix_v23(
    out, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)

    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H

    # Suffix segment: rope columns, broadcast across heads.
    c = col_job * BC + tl.arange(0, BC)
    cmask = c < DR
    val = tl.load(
        rope + token * RS0 + c[None, :] * RS2,
        mask=cmask[None, :], other=0,
        eviction_policy="evict_last",
    ).to(COMMON)
    val = tl.broadcast_to(val, (BH, BC))
    mask = hmask[:, None] & cmask[None, :]

    tl.store(
        out + (token * H + heads[:, None]) * (DN + DR) + (DN + c)[None, :],
        val, mask=mask, eviction_policy="evict_first",
    )


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31

    if dn > 0:
        grid_p = lambda meta: (
            tokens,
            triton.cdiv(heads, meta["BH"]),
            triton.cdiv(dn, meta["BC"]),
        )
        _concat_prefix_v23[grid_p](
            out, k_nope, tokens, heads, dn, dr,
            *ns,
            COMMON=common, WIDE=wide,
        )

    if dr > 0:
        grid_s = lambda meta: (
            tokens,
            triton.cdiv(heads, meta["BH"]),
            triton.cdiv(dr, meta["BC"]),
        )
        _concat_suffix_v23[grid_s](
            out, k_rope, tokens, heads, dn, dr,
            rs[0], rs[2],
            COMMON=common, WIDE=wide,
        )

    return out


__all__ = ["concat_and_cast_mha_k"]