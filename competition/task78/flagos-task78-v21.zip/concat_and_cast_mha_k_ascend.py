"""Task 78 v21: Ascend token/head tiles with head-vectorized RoPE broadcast."""
import torch
import triton
import triton.language as tl


@triton.jit
def _concat_token_head_tiles_v21(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BT: tl.constexpr, HS: tl.constexpr, HS_PAD: tl.constexpr,
    BN: tl.constexpr, BR: tl.constexpr,
    HEAD_JOBS: tl.constexpr, JOBS: tl.constexpr,
):
    for job in range(tl.program_id(0), JOBS, tl.num_programs(0)):
        # Scalar division per work tile only; tensor axes stay [tokens, heads, cols].
        if WIDE:
            work = job.to(tl.int64)
        else:
            work = job
        first_token = (work // HEAD_JOBS) * BT
        first_head = (work % HEAD_JOBS) * HS

        tokens = first_token + tl.arange(0, BT)
        heads = first_head + tl.arange(0, HS_PAD)
        token_ok = tokens[:, None, None] < T
        head_ok = (heads[None, :, None] < H) & (heads[None, :, None] < first_head + HS)
        rows = tokens[:, None, None] * H + heads[None, :, None]

        if DR > 0:
            # RoPE suffix is loaded once per tile as [tokens, cols] and
            # broadcast across the head axis of the tile on store.
            rc = tl.arange(0, BR)
            if WIDE:
                rc = rc.to(tl.int64)
            rope_mask = (tokens[:, None] < T) & (rc[None, :] < DR)
            rope_value = tl.load(
                rope + tokens[:, None] * RS0 + rc[None, :] * RS2,
                mask=rope_mask, other=0,
            ).to(COMMON)

        if DN > 0:
            nc = tl.arange(0, BN)
            if WIDE:
                nc = nc.to(tl.int64)
            for first_col in range(0, DN, BN):
                cols = first_col + nc
                valid = token_ok & head_ok & (cols[None, None, :] < DN)
                value = tl.load(
                    nope + tokens[:, None, None] * NS0
                    + heads[None, :, None] * NS1
                    + cols[None, None, :] * NS2,
                    mask=valid, other=0,
                ).to(COMMON)
                tl.store(out + rows * (DN + DR) + cols[None, None, :],
                         value, mask=valid)

        if DR > 0:
            rope_tile = rope_mask[:, None, :] & head_ok
            tl.store(out + rows * (DN + DR) + DN + rc[None, None, :],
                     rope_value[:, None, :], mask=rope_tile)


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    bn = min(512, triton.next_power_of_2(max(1, dn)))
    br = triton.next_power_of_2(max(1, dr))
    # Head-vectorized tiles: each program covers BT tokens x HS heads at once,
    # so the RoPE suffix is loaded once and stored HS times from registers.
    hs = min(8, heads)
    hs_pad = triton.next_power_of_2(hs)
    bt = min(4, triton.next_power_of_2(tokens),
             max(1, 4096 // max(bn * hs_pad, br)))
    head_jobs = triton.cdiv(heads, hs)
    jobs = triton.cdiv(tokens, bt) * head_jobs
    _concat_token_head_tiles_v21[(min(32, jobs),)](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BT=bt, HS=hs, HS_PAD=hs_pad,
        BN=bn, BR=br,
        HEAD_JOBS=head_jobs, JOBS=jobs, num_warps=4, num_stages=1,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
