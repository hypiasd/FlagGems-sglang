"""Task 78 v21: Kunlunxin, serial heads sharing one 1-D RoPE vector.

v22 structural change: the kernel is split into two fully separate
phases with distinct bounded column traversal.

  Phase A (prefix): the nope region is traversed head-major with a
  bounded tile loop; each tile uses its own safe masked pointer built
  from the nope strides.

  Phase B (suffix): the shared RoPE vector is loaded exactly once per
  token job into registers, then stored for every serial head with a
  separate masked pointer over the output's rope region.

All addressing stays 1-D vector arithmetic; no multidimensional
broadcast tensors, no flat output div/mod, no autotune, no
nonessential cache hints.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _concat_serial_heads_v21(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    HS: tl.constexpr, BN: tl.constexpr, BR: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
    first_head = head_job * HS

    # ---------------- Phase A: prefix (nope) region ----------------
    # Head-major bounded traversal: for each serial head, walk the nope
    # columns in BN-sized tiles with a dedicated masked pointer.
    if DN > 0:
        nc = tl.arange(0, BN)
        if WIDE:
            nc = nc.to(tl.int64)
        for h in tl.static_range(0, HS):
            head = first_head + h
            head_ok = head < H
            src = nope + token * NS0 + head * NS1
            dst = (token * H + head) * (DN + DR)
            for first_col in range(0, DN, BN):
                cols = first_col + nc
                valid = head_ok & (cols < DN)
                value = tl.load(src + cols * NS2, mask=valid,
                                other=0).to(COMMON)
                tl.store(out + dst + cols, value, mask=valid)

    # ---------------- Phase B: suffix (rope) region ----------------
    # Load the shared rope vector once per token job, then scatter it to
    # every serial head's rope slot with its own masked pointer.
    if DR > 0:
        rc = tl.arange(0, BR)
        if WIDE:
            rc = rc.to(tl.int64)
        rope_value = tl.load(rope + token * RS0 + rc * RS2,
                             mask=rc < DR, other=0).to(COMMON)
        for h in tl.static_range(0, HS):
            head = first_head + h
            dst = (token * H + head) * (DN + DR) + DN
            tl.store(out + dst + rc, rope_value,
                     mask=(head < H) & (rc < DR))


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    # Serial-head reuse: more heads per job when the nope tile is small,
    # amortizing the rope load and program overhead; bounded for safety.
    if dn <= 128:
        hs = min(8, heads)
    elif dn <= 256:
        hs = min(4, heads)
    else:
        hs = min(2, heads)
    bn = min(512, triton.next_power_of_2(max(1, dn)))
    br = triton.next_power_of_2(max(1, dr))
    _concat_serial_heads_v21[(tokens, triton.cdiv(heads, hs))](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, HS=hs, BN=bn, BR=br,
        num_warps=2, num_stages=1,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
