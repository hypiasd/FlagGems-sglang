"""Task 78 v21: International A/B, two-segment prefix/suffix tile schedule.

Structural change from v19: instead of one tile spanning the nope/rope
boundary with per-lane `tl.where` merging, the column grid is split into a
prefix segment (pure nope tiles) and a suffix segment (pure rope tiles).
Each segment runs a straight-line load/store path with no cross-source
select, and rope values are loaded once per tile and broadcast over heads.
Streaming eviction hints are added for the single-use loads/stores.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _concat_two_segment_v21(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr, NP: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H

    if col_job >= NP:
        # Suffix segment: rope columns, broadcast across heads.
        c = (col_job - NP) * BC + tl.arange(0, BC)
        cmask = c < DR
        val = tl.load(
            rope + token * RS0 + c[None, :] * RS2,
            mask=cmask[None, :], other=0,
            eviction_policy="evict_last",
        ).to(COMMON)
        val = tl.broadcast_to(val, (BH, BC))
        cols = DN + c
        mask = hmask[:, None] & cmask[None, :]
    else:
        # Prefix segment: nope columns, direct 2-D tile load.
        c = col_job * BC + tl.arange(0, BC)
        cmask = c < DN
        mask = hmask[:, None] & cmask[None, :]
        val = tl.load(
            nope + token * NS0 + heads[:, None] * NS1 + c[None, :] * NS2,
            mask=mask, other=0,
            eviction_policy="evict_last",
        ).to(COMMON)
        cols = c

    tl.store(
        out + (token * H + heads[:, None]) * (DN + DR) + cols[None, :],
        val, mask=mask, eviction_policy="evict_first",
    )


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    bh = min(4, triton.next_power_of_2(heads))
    bc = min(1024, triton.next_power_of_2(total_dim))
    bh = min(bh, max(1, 4096 // bc))
    npfx = triton.cdiv(dn, bc)
    grid = (tokens, triton.cdiv(heads, bh), npfx + triton.cdiv(dr, bc))
    _concat_two_segment_v21[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BH=bh, BC=bc, NP=npfx,
        num_warps=4, num_stages=1,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
