"""Task 78 v21: Hygon, separate prefix/suffix output subtiles with split stores."""
import torch
import triton
import triton.language as tl


@triton.jit
def _concat_output_tile_v21(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    cols = col_job * BC + tl.arange(0, BC)
    hmask = heads[:, None] < H
    # v21 structural change: prefix and suffix subtiles are stored separately
    # with their own masks, eliminating the merge tl.where and letting each
    # subtile compile to a tight masked store over its own column range.
    is_pre = cols[None, :] < DN
    is_suf = (cols >= DN) & (cols < DN + DR)
    # Clamp negative inactive suffix offsets; merge values after promotion.
    nc = cols
    rc = tl.maximum(cols - DN, 0)
    prefix = tl.load(
        nope + token * NS0 + heads[:, None] * NS1 + nc[None, :] * NS2,
        mask=hmask & is_pre, other=0,
        eviction_policy='evict_last',
    ).to(COMMON)
    suffix = tl.load(
        rope + token * RS0 + rc * RS2,
        mask=is_suf, other=0,
        eviction_policy='evict_last',
    ).to(COMMON)
    # Safe output-aligned token/head/column mapping (v19 schedule preserved).
    base = out + (token * H + heads[:, None]) * (DN + DR) + cols[None, :]
    tl.store(base, prefix, mask=hmask & is_pre, eviction_policy='evict_first')
    tl.store(base, suffix, mask=hmask & is_suf, eviction_policy='evict_first')


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    bc = min(1024, triton.next_power_of_2(total_dim))
    bh = min(4, triton.next_power_of_2(heads))
    bh = min(bh, max(1, 4096 // bc))
    # Wider column tiles are bandwidth-bound; give them more warps.
    num_warps = 8 if bc >= 512 else 4
    _concat_output_tile_v21[(tokens, triton.cdiv(heads, bh),
                             triton.cdiv(total_dim, bc))](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BH=bh, BC=bc,
        num_warps=num_warps, num_stages=1,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
