"""Task 78 v21: Iluvatar, two-stage prefix/suffix tile schedule with head reuse."""
import torch
import triton
import triton.language as tl


@triton.jit
def _concat_two_stage_v21(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr, NP: tl.constexpr,
):
    token = tl.program_id(0)
    head_job = tl.program_id(1)
    col_job = tl.program_id(2)
    if WIDE:
        token = token.to(tl.int64)
        head_job = head_job.to(tl.int64)
        col_job = col_job.to(tl.int64)
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    out_row = (token * H + heads[:, None]) * (DN + DR)
    # Stage 1: prefix tiles read only from k_nope (dense, no wasted lanes).
    if col_job < NP:
        cols = col_job * BC + tl.arange(0, BC)
        cmask = cols < DN
        m = hmask[:, None] & cmask[None, :]
        v = tl.load(
            nope + token * NS0 + heads[:, None] * NS1 + cols[None, :] * NS2,
            mask=m, other=0, eviction_policy='evict_last',
        ).to(COMMON)
        tl.store(out + out_row + cols[None, :], v, mask=m)
    # Stage 2: suffix tiles read only from k_rope (one scalar row broadcast).
    else:
        cols = (col_job - NP) * BC + tl.arange(0, BC)
        cmask = cols < DR
        v = tl.load(
            rope + token * RS0 + cols * RS2,
            mask=cmask, other=0, eviction_policy='evict_last',
        ).to(COMMON)
        m = hmask[:, None] & cmask[None, :]
        tl.store(out + out_row + (DN + cols)[None, :],
                 tl.broadcast_to(v[None, :], (BH, BC)), mask=m)


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    bc = min(2048, triton.next_power_of_2(total_dim))
    bh = min(8, triton.next_power_of_2(heads))
    bh = min(bh, max(1, 4096 // bc))
    np_tiles = triton.cdiv(dn, bc)
    ns_tiles = triton.cdiv(dr, bc)
    _concat_two_stage_v21[(tokens, triton.cdiv(heads, bh), np_tiles + ns_tiles)](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide, BH=bh, BC=bc, NP=np_tiles,
        num_warps=4, num_stages=1,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
