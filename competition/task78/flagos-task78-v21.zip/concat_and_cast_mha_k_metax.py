"""Task 78 v21 repair: MetaX, two-segment prefix/suffix tile schedule, plain Triton ops."""
import torch
import triton
import triton.language as tl


@triton.jit
def _concat_output_tile_v21(
    out, nope, rope,
    T: tl.constexpr, H: tl.constexpr, DN: tl.constexpr, DR: tl.constexpr,
    NS0: tl.constexpr, NS1: tl.constexpr, NS2: tl.constexpr,
    RS0: tl.constexpr, RS2: tl.constexpr,
    COMMON: tl.constexpr, WIDE: tl.constexpr,
    BH: tl.constexpr, BC: tl.constexpr,
):
    token = tl.program_id(0)
    if WIDE:
        token = token.to(tl.int64)
    head_job = tl.program_id(1)
    seg_job = tl.program_id(2)
    if WIDE:
        head_job = head_job.to(tl.int64)
        seg_job = seg_job.to(tl.int64)
    # Two-segment schedule: low bit selects prefix (nope) or suffix (rope),
    # remaining bits index the column tile within that segment. Each program
    # touches exactly one source tensor, so no lanes are wasted on masked-out
    # loads of the other segment.
    seg = seg_job % 2
    ct = seg_job // 2
    heads = head_job * BH + tl.arange(0, BH)
    hmask = heads < H
    cols = ct * BC + tl.arange(0, BC)
    out_base = out + (token * H + heads[:, None]) * (DN + DR)
    if seg == 0:
        cmask = cols < DN
        valid = hmask[:, None] & cmask[None, :]
        # Clamp masked source offsets into range to keep addresses safe.
        src_cols = tl.where(cmask, cols, 0)
        src_heads = tl.where(hmask, heads, 0)
        v = tl.load(
            nope + token * NS0 + src_heads[:, None] * NS1 + src_cols[None, :] * NS2,
            mask=valid, other=0, eviction_policy='evict_first',
        ).to(COMMON)
        tl.store(out_base + cols[None, :], v, mask=valid)
    else:
        cmask = cols < DR
        # Source mask shaped [1, BC]: rope has a single head, so the load
        # operates on one row; the loaded value then broadcasts to [BH, BC]
        # for the store.
        src_valid = cmask[None, :]
        src_cols = tl.where(cmask, cols, 0)
        v = tl.load(
            rope + token * RS0 + src_cols[None, :] * RS2,
            mask=src_valid, other=0, eviction_policy='evict_first',
        ).to(COMMON)
        valid = hmask[:, None] & cmask[None, :]
        tl.store(out_base + (DN + cols)[None, :], v, mask=valid)


def concat_and_cast_mha_k(k, k_nope, k_rope):
    out = torch.empty(k.shape, dtype=k.dtype, device=k.device,
                      memory_format=torch.contiguous_format)
    tokens, heads, total_dim = k.shape
    if tokens == 0 or heads == 0 or total_dim == 0:
        return out
    dn, dr = k_nope.shape[2], k_rope.shape[2]
    if dn == 0 and dr == 0:
        return out
    common = getattr(tl, str(torch.promote_types(k_nope.dtype, k_rope.dtype)).split(".")[-1])
    # Use native-width indices on ordinary tensors, widen before multiplication
    # when any relative address needs more than signed 32 bits.
    ns, rs = k_nope.stride(), k_rope.stride()
    span = max(tokens * heads * total_dim,
               (tokens - 1) * ns[0] + (heads - 1) * ns[1] + max(dn - 1, 0) * ns[2] + 1,
               (tokens - 1) * rs[0] + max(dr - 1, 0) * rs[2] + 1)
    wide = span >= 2**31
    BH = 8 if heads < 32 else 16
    BC = 512
    grid = (tokens, triton.cdiv(heads, BH), 2 * (triton.cdiv(dn, BC) + triton.cdiv(dr, BC)))
    _concat_output_tile_v21[grid](
        out, k_nope, k_rope, tokens, heads, dn, dr,
        *ns, rs[0], rs[2],
        COMMON=common, WIDE=wide,
        BH=BH, BC=BC,
        num_warps=8, num_stages=2,
    )
    return out


__all__ = ["concat_and_cast_mha_k"]
